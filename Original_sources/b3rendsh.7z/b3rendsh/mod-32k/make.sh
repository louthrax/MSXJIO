#!/bin/bash

# Make Z80 binary from ASM source with z88dk tools

if [ "$1" == "rom" ]; then
    echo "Assembling ROM..."
    obj="./obj/"
    target="ROM"
    rm -rf "$obj"*
    z88dk.z88dk-z80asm -b -d -l -m -D$target -O$obj -o=msxd22s.bin msxd22s0.asm driver.asm msxd22s1.asm msxd22s2.asm
    z88dk.z88dk-appmake +glue -b "$obj"msxd22s --filler 0xFF --clean
    z88dk.z88dk-appmake +rom -b "$obj"msxd22s__.bin -o msxd22s.rom -s 32768 --org 0
    echo "Done."

elif [ "$1" == "fat16" ]; then
    echo "Compiling FAT16..."
    obj="./obj/"
    target="FAT16"
    rm -rf "$obj"*
    z88dk.z88dk-z80asm -b -d -l -m -D$target -O$obj -o=msxd22s.bin msxd22s0.asm driver.asm msxd22s1.asm msxd22s2.asm
    z88dk.z88dk-appmake +glue -b "$obj"msxd22s --filler 0xFF --clean
    z88dk.z88dk-appmake +rom -b "$obj"msxd22s__.bin -o msxd22sx.rom -s 32768 --org 0
    echo "Done."

elif [ "$1" == "test" ]; then
    echo "Compiling TEST..."
    obj="./objtest/"
    target="TEST"
    z88dk.z88dk-z80asm -b -d -l -m -D$target -O$obj -o=msxd22s.bin msxd22s0.asm driver.asm msxd22s1.asm msxd22s2.asm
    z88dk.z88dk-appmake +glue -b "$obj"msxd22s --filler 0xFF --clean
    z88dk.z88dk-appmake +rom -b "$obj"msxd22s__.bin -o msxd22t.rom -s 32768 --org 0
    grep "^DOS_" "$obj"msxd22s.map > "$target"_entry_points.txt
    echo "Done."

elif [ "$1" == "clean" ]; then
    echo "Cleaning up..."
    rm -rf ./obj/* ./objtest/*
    echo "Cleanup done."

else
    echo "Usage: $0 [rom|fat16|test|clean]"
fi
