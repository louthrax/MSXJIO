#!/usr/bin/env bash

cd "$(dirname "$0")"

python3 ./server.py /dev/ttyUSB0 ../disks/aleste2_00.dsk
