import serial
import sys
import time
import msvcrt
from threading import Thread

def calculate_checksum(data):
    """Calculate checksum as sum of bytes with overflow bit handling."""
    checksum = 0
    for byte in data:
        checksum += byte
        # If we have overflow (9th bit set), add it back to sum
        if checksum > 0xFF:
            checksum = (checksum & 0xFF) + 1
    return checksum & 0xFF

def respond(ser, message):
    """Send response with protocol formatting and checksum."""
    # Wait 2ms
    # time.sleep(0.002)
    
    # Convert message to bytes if it's not already
    if not isinstance(message, bytes):
        if isinstance(message, int):
            message = bytes([message])
        else:
            message = bytes(message)
    
    # Prepare full message: 0xF0 + message + checksum
    full_message = bytes([0xFF] *3) + bytes([0xF0]) + message
    checksum = calculate_checksum(message)  # Calculate checksum of the message only
    full_message += bytes([checksum])
    
    # Send the message
    ser.write(full_message)

def main():
    if len(sys.argv) != 3:
        print("Usage: program.py COM_PORT IMAGE_FILE")
        return

    com_port = sys.argv[1]
    image_file = sys.argv[2]

    try:
        # Open serial port
        ser = serial.Serial(
            port=com_port,
            baudrate=115200,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE
        )
        
        # Open disk image file
        with open(image_file, "r+b") as f:
            # Read MediaDescriptor from byte 512
            f.seek(512)
            media_descriptor = f.read(1)[0]
            # Clear bit 7
            media_descriptor &= 0x7F        

            # Main loop
            while True:
                # Check for ESC key
                if msvcrt.kbhit():
                    if msvcrt.getch() == b'\x1b':  # ESC key
                        break
                
                # Wait for command byte
                if ser.in_waiting > 0:
                    cmd = ser.read(1)[0]
                    
                    if cmd == ord('D'):  # Descriptor request
                        respond(ser, media_descriptor)
                        media_descriptor |= 0x80 
                        print(f"Media descriptor: {media_descriptor}")
                        
                    elif cmd == ord('R'):  # Read request
                        # Read sector number (2 bytes, little endian)
                        sector_low = ser.read(1)[0]
                        sector_high = ser.read(1)[0]
                        sector = sector_low + (sector_high << 8)
                        print(f"Read: {sector}")

                        # Calculate file offset
                        offset = sector * 512
                        
                        # Read 512 bytes from file
                        f.seek(offset)
                        data = f.read(512)
                        
                        # Send data
                        respond(ser, data)

                        
                    elif cmd == ord('W'):  # Write request
                        # Read sector number
                        sector_low = ser.read(1)[0]
                        sector_high = ser.read(1)[0]
                        sector = sector_low + (sector_high << 8)
                        print(f"Write: {sector}")

                        # Read 512 bytes of data + checksum
                        data = ser.read(512)
                        received_checksum = ser.read(1)[0]                     
                        # Verify checksum
                        calculated_checksum = calculate_checksum(data)
                        
                        if calculated_checksum == received_checksum:
                            # Write data to file
                            offset = sector * 512
                            f.seek(offset)
                            f.write(data)
                            f.flush()
                            
                            # Send success response
                            respond(ser, bytes([0x00]))
                        else:
                            print(f"Checksum failed: {sector}") 
                            # Send error response
                            respond(ser, bytes([0xFF]))
                            print(f"Warning: Checksum mismatch at sector {sector}")

    except serial.SerialException as e:
        print(f"Serial port error: {e}")
    except IOError as e:
        print(f"File error: {e}")
    finally:
        ser.close()

if __name__ == "__main__":
    main()